package control;

public class Principal {

	public static void main(String[] args) {
		Ventana obj= new Ventana();
		obj.setVisible(true);
	}
}
