package baseDatos;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;

/*import control.Historial;
import control.Registro;*/
import modelo.Estudiante;

import java.sql.Connection;

public class EstudianteIMPA implements EstudianteIMP{
	private AdminBD admin;
	private Connection conexion;
	private boolean conexionTransferida;
	
	public EstudianteIMPA() {
		admin = new AdminBD();		
		conexion=null;
	}
	
	public EstudianteIMPA(Connection conexion) {
		this.conexion=conexion;
		conexionTransferida=true;
	}
	
	public int insertar(Estudiante estudiante) {
		int verificar=0;
		PreparedStatement ps=null;

		String sql="INSERT INTO estudiantes(matricula,nombre,apellidop) VALUES(?,?,?);";
		if(conexionTransferida==false)
			conexion=admin.dameConexion();
		
		try {
			ps=conexion.prepareStatement(sql);

			ps.setString(1, estudiante.getMatricula());
			ps.setString(2, estudiante.getNombre());
			ps.setString(3, estudiante.getApellidop());
	
			try{
				ps.executeUpdate();
			}catch(SQLException e) {
				JOptionPane.showMessageDialog(null, "Los datos ya estan registrados");
			
			}finally {
				/*Registro obj = new Registro();
			    obj.setVisible(true);*/
				ps.close();
			}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				if(conexionTransferida==false)
					conexion.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return verificar;
	}
}
