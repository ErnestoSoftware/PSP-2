package baseDatos;

import modelo.Estudiante;

public interface EstudianteIMP {
	public int insertar(Estudiante estudiante);
}
